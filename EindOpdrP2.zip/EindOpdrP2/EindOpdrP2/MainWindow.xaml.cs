﻿using System.ComponentModel;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using static System.Runtime.InteropServices.JavaScript.JSType;



namespace EindOpdrP2
{
    public partial class MainWindow : Window
    {
        private DispatcherTimer _timer;
        private Random _random;
        private List<Canvas> _fishes;

        public MainWindow()
        {
            InitializeComponent();
            _random = new Random();
            _fishes = new List<Canvas>();

            _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(900) };
            _timer.Tick += (s, e) => MoveFish();
            Laadinbestand(); // Load fish when the application starts
        }

        private void AquariumCanvas_Loaded(object sender, RoutedEventArgs e) => _timer.Start();

        // Move the fish every timer tick
        private void MoveFish()
        {
            foreach (var fishContainer in _fishes)
            {
                // Genereer een volledig willekeurige positie binnen de grenzen van het canvas
                double newLeft = _random.NextDouble() * (AquariumCanvas.ActualWidth - fishContainer.Width);
                double newTop = _random.NextDouble() * (AquariumCanvas.ActualHeight - fishContainer.Height);

                // Stel de nieuwe positie in
                Canvas.SetLeft(fishContainer, newLeft);
                Canvas.SetTop(fishContainer, newTop);
            }
        }



        // Get color based on ComboBox selection


        private Color GetColorFromComboBox(string selectedColor)
        {
            switch (selectedColor.ToLowerInvariant())
            {
                case "rood": return Colors.Red;
                case "blauw": return Colors.Blue;
                case "groen": return Colors.Green;
                case "geel": return Colors.Yellow;
                default: throw new ArgumentException($"Ongeldige kleur gekozen: {selectedColor}");
                    Color color = (Color)ColorConverter.ConvertFromString("#FFDFD991");
            }
        }


        // Create a new fish and add it to the canvas



        private Canvas CreateFish(string name, double size, Color color)
        {
            
            var fishContainer = new Canvas { Width = size, Height = size / 2 };

           
            var fish = new Ellipse { Width = size, Height = size / 2, Fill = new SolidColorBrush(color) };

           
            var fishName = new TextBlock
            {
                Text = name,
                Foreground = Brushes.White,
                FontSize = 14,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };

          
            fishContainer.Children.Add(fish);
            fishContainer.Children.Add(fishName);

           
            double textBlockWidth = fishName.ActualWidth;  // Haal de breedte van de TextBlock op
            double textBlockHeight = fishName.ActualHeight; // Haal de hoogte van de TextBlock op

            // Plaats de TextBlock in het midden van de Ellipse
            Canvas.SetLeft(fishName, (fishContainer.Width - textBlockWidth) / 2);
            Canvas.SetTop(fishName, (fishContainer.Height - textBlockHeight) / 2);

            // Stel de viscontainer in op een willekeurige positie binnen het aquarium
            Canvas.SetLeft(fishContainer, _random.NextDouble() * (AquariumCanvas.ActualWidth - fishContainer.Width));
            Canvas.SetTop(fishContainer, _random.NextDouble() * (AquariumCanvas.ActualHeight - fishContainer.Height));

            // Voeg de viscontainer toe aan het aquariumcanvas
            AquariumCanvas.Children.Add(fishContainer);

            return fishContainer;
        }


        // Save the fish to a file


        private void SaveFishToFile(string name, double size, Color color)
        {
            string colorHex = color.ToString(); // Converteer de kleur naar hexadecimaal formaat
            File.AppendAllText("vissen.txt", $"{name}, {size}, {colorHex}{Environment.NewLine}");
        }


        // Load fish from file when the application starts
       
        
        private void Laadinbestand()
        {
            string filePath = "vissen.txt";
            if (File.Exists(filePath))
            {
                try
                {
                    var lines = File.ReadAllLines(filePath);

                    foreach (var line in lines)
                    {
                        if (string.IsNullOrWhiteSpace(line)) continue;

                        var parts = line.Split(',');

                        if (parts.Length == 3)
                        {
                            string name = parts[0].Trim();
                            string sizeText = parts[1].Trim();
                            string colorHex = parts[2].Trim();

                            if (double.TryParse(sizeText, out double size) && size > 0)
                            {
                               
                                {
                                    // Gebruik de ColorConverter om de hexadecimale kleur te parsen
                                    Color color = (Color)ColorConverter.ConvertFromString(colorHex);

                                    // Maak de vis en voeg deze toe aan het aquarium
                                    var fish = CreateFish(name, size, color);
                                    _fishes.Add(fish);
                                    lbvisen.Items.Add(name);
                                }
                                
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Er is een fout opgetreden: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Het bestand bestaat niet.");
            }
        }
        // Remove the fish from the file
        private void verwijdervanbestand(string fishName)
        {
            string filePath = "vissen.txt";
            if (!File.Exists(filePath)) return;

            try
            {
                var lines = File.ReadAllLines(filePath);
                var updatedLines = lines.Where(line => !line.StartsWith(fishName + ",")).ToArray();
                File.WriteAllLines(filePath, updatedLines);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Er is een fout opgetreden bij het bijwerken van het bestand: {ex.Message}");
            }
        }

        private void toevoegen_Click(object sender, RoutedEventArgs e)
        {
            string name = tbNaam.Text.Trim();

            if (string.IsNullOrEmpty(name) ||
                !double.TryParse(tbGrootte.Text, out double size) ||
                size <= 0 ||
                cbKleur.SelectedItem == null)
            {
                MessageBox.Show("Zorg ervoor dat alle velden correct zijn ingevuld.");
                return;
            }
            if (lbvisen.Items.Contains(name))
            {
                MessageBox.Show("De visnaam bestaat al. Kies een andere naam.");
                return;
            }

            try
            {
                var selectedItem = cbKleur.SelectedItem as ComboBoxItem;
                string selectedColor = selectedItem?.Content.ToString() ?? string.Empty;

                var color = GetColorFromComboBox(selectedColor);
                var fish = CreateFish(name, size, color);
                _fishes.Add(fish);
                lbvisen.Items.Add(name);
                SaveFishToFile(name, size, color);
                MessageBox.Show("Vis is toegevoegd");
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show($"Fout bij het toevoegen van de vis: {ex.Message}");
            }
        }


        private void verwijderen_Click(object sender, RoutedEventArgs e)
        {
            if (lbvisen.SelectedIndex < 0) return;

            string fishName = lbvisen.SelectedItem.ToString();

            var fishContainerToRemove = _fishes.FirstOrDefault(f => ((TextBlock)f.Children[1]).Text == fishName);
            if (fishContainerToRemove != null)
            {
                AquariumCanvas.Children.Remove(fishContainerToRemove);
                _fishes.Remove(fishContainerToRemove);
                lbvisen.Items.Remove(fishName);
                verwijdervanbestand(fishName);
                MessageBox.Show("Vis is verwijderd");
            }
            else
            {
                MessageBox.Show("De geselecteerde vis is niet gevonden.");
            }
        }
    }
}
