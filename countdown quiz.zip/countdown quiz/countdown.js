
        const questions = [
            { question: "Wat is 2 + 2?", answer: "4" },
            { question: "Wat is de hoofdstad van Frankrijk?", answer: "Parijs" },
            { question: "wat is de voor naam van .... gate", answer: "Bill" },
            { question: "wat is de koning van de jungle", answer: "leeuw" },
            { question: "wie is de mogol van de klas", answer: "Tigo" },
            { question: "wie heeft de lekkerste zus", answer: "Aliysa" },
            { question: "wie zijn haarlijn is bijna loes", answer: "merijn {A-Za-z" },
            { question: "Hoeveel dagen heeft een jaar?", answer: "365" },
            { question: "wat is zwarder 1kg steen of 1 kg veren (je kan kiezen tussen steen , even, veer)", answer: "even" },
            { question: "wie is soldaat", answer: "Nizar" }
        ];

        let currentQuestionIndex = 0;
        let score = 0;
        let timer;
        let time = 20;

        function startQuiz() {
            showQuestion();
            startTimer();
        }

       
        function showQuestion() {
            clearInterval(timer); // Stop de huidige timer
            if (currentQuestionIndex < questions.length) {
                document.getElementById('question').innerText = questions[currentQuestionIndex].question;
                document.getElementById('timer').innerText = time;
                document.getElementById('feedback').classList.remove('show', 'correct', 'incorrect');
                document.getElementById('answerField').value = '';
                document.getElementById('submitAnswer').disabled = false;
                startTimer(); // Start een nieuwe timer
            } else {
                showScore();
            }
        }
        

        function startTimer() {
            if (timer) {
                clearInterval(timer); // Stop een oude timer als die bestaat
            }
            time = 20;
            document.getElementById('timer').innerText = time;
        
            timer = setInterval(() => {
                time--;
                document.getElementById('timer').innerText = time;
        
                if (time <= 0) {
                    clearInterval(timer);
                    document.getElementById('feedback').innerText = "Tijd om!";
                    document.getElementById('feedback').classList.add('show', 'incorrect');
                    document.getElementById('submitAnswer').disabled = true;
                    currentQuestionIndex++;
                    setTimeout(showQuestion, 2000); // Toon de volgende vraag na een korte pauze
                }
            }, 1000);
        }
        

        function submitAnswer() {
            clearInterval(timer);
            const answer = document.getElementById('answerField').value.trim();
            const correctAnswer = questions[currentQuestionIndex].answer.toLowerCase();
            const feedback = document.getElementById('feedback');

            if (answer === correctAnswer) {
                score++;
                feedback.textContent = "Goed gedaan! Je antwoord is juist.";
                feedback.className = 'feedback show correct';
            } else {
                feedback.textContent = "Helaas, dat is niet het juiste antwoord.";
                feedback.className = 'feedback show incorrect';
            }

            document.getElementById('submitAnswer').disabled = true;
            currentQuestionIndex++;
            setTimeout(showQuestion, 2000); // Toon de volgende vraag na een korte pauze
        }

        function showScore() {
            document.getElementById('quiz-container').innerHTML = `
                <h2>Quiz voltooid!</h2>
                <p>Je score: ${score} van ${questions.length}</p>
            `;
        }

        // Start de quiz bij het laden van de pagina
        window.onload = startQuiz;
   